package controller;

import java.io.File;

import ch.majesty.model.Player;
import clientserver.Client;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Main extends Application {
	public  Main(){
	}

	private Stage primaryStage;
	private LoginController controller;
	private GameController gcontroller;
	private Client client;

	private ObservableList<Player> playerData = FXCollections.observableArrayList();


	@Override
	public void start(Stage primaryStage) throws Exception {
		this.primaryStage = primaryStage;
		loginWindow(); // beim start wird das loginwindow aufgebaut
	}

	public void loginWindow() {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/LoginView.fxml"));
			AnchorPane pane = loader.load(); // das erste ist AnchorPane, das
			// wird jetzt geladen!
			Scene scene = new Scene(pane); // eine szene wird gebaut!
			Stage stage = new Stage();


			scene.getStylesheets().add("/view/style.css"); // CSS einbindung!

			
			controller = loader.getController();
			
			controller.setMain(this); // eigenes objekt geben!
			controller.setStage(stage);

			primaryStage.setTitle("Majesty - Login");
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void gameWindow() {
		try {
			FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/GameView.fxml"));
			AnchorPane pane = loader.load(); // das erste ist AnchorPane, das
			// wird jetzt geladen!
			Scene scene = new Scene(pane); // eine szene wird gebaut!
			Stage stage = new Stage();
			
			String usernameField = controller.getUsernameField().getText();
			String ipAdressField = controller.getIpAdressField().getText();
			
			gcontroller = loader.getController();
			gcontroller.setMain(this); // eigenes objekt geben!
			gcontroller.setStage(stage);
			client = new Client(usernameField, ipAdressField, gcontroller);
			
			primaryStage.setTitle("Majesty - Spiel");
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static void main(String[] args) {
		launch(args);
	}

	public ObservableList<Player> getPlayerData() {
		return playerData;
	}



}
