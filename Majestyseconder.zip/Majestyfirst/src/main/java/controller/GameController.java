package controller;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Observable;
import java.util.Optional;

import com.sun.javafx.util.Utils;

import ch.majesty.model.CardType;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


public class GameController {
	@FXML ImageView player1muehle;
	@FXML ImageView player1brauerei;
	@FXML ImageView player1hexenhaus;
	@FXML ImageView player1wachturm;
	@FXML ImageView player1kaserne;
	@FXML ImageView player1caverne;
	@FXML ImageView player1schloss;
	@FXML ImageView player1lazarett; 

	@FXML ImageView playerAdlige;
	@FXML ImageView playerBrauer;
	@FXML ImageView playerMuellerin;
	@FXML ImageView playerWachen;
	@FXML ImageView playerWirt;
	@FXML ImageView playerSoldat;

	@FXML Button card0;
	@FXML Button card1;
	@FXML Button card2;
	@FXML Button card3;
	@FXML Button card4;
	@FXML Button card5;

	private Main main;
	private Stage stage;



	public void setMain(Main main) {
		this.main = main;
	}

	public void initialize() {
		// diese methode braucht man um das mapping model->view zu erstellen.
		// diese methode muss initialize heissen!
		// überschrieben!
	}


	public void handleEdit() {

	}

	public void spielregelnButton() {
		try {
			Desktop.getDesktop().open(new File("/Users/Gezim/Documents/workspace22/MajestyGame/src/rules/Majesty_Spielanleitung.pdf"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	public void refillCards(){
		setCard(0, card0);
		setCard(1, card1);
		setCard(2, card2);
		setCard(3, card3);
		setCard(4, card4);
		setCard(5, card5);
		
		if(main.getController().getClient().getThisPlayer().isYourTurn()) {
			card0.setDisable(false);
			card1.setDisable(false);
			card2.setDisable(false);
			card3.setDisable(false);
			card4.setDisable(false);
			card5.setDisable(false);
		} else {
			card0.setDisable(true);
			card1.setDisable(true);
			card2.setDisable(true);
			card3.setDisable(true);
			card4.setDisable(true);
			card5.setDisable(true);
		}
	}



	public void setCard(int i, Button button) {
		CardType type = main.getClient().getMarket().getList().get(i);
		// get CardType from array
		Image image;
		switch (type) {
		case MILLER:
			image = new Image("ressource/character_cards/Muellerin.jpg");
			button.setGraphic(new ImageView(image));
			break;
		case BREWER:
			image = new Image("ressource/character_cards/Brauer.jpg");
			button.setGraphic(new ImageView(image));
			break;
		case GUARD:
			image = new Image("ressource/character_cards/Wachen.jpg");
			button.setGraphic(new ImageView(image));
			break;
		case INNKEEPER:
			image = new Image("ressource/character_cards/Wirt.jpg");
			button.setGraphic(new ImageView(image));
			break;
		case KNIGHT:
			image = new Image("ressource/character_cards/Soldat.jpg");
			button.setGraphic(new ImageView(image));
			break;
		case NOBLE:
			image = new Image("ressource/character_cards/Adlige.jpg");
			button.setGraphic(new ImageView(image));
			break;
		case WITCH:
			image = new Image("ressource/character_cards/Hexe.jpg");
			button.setGraphic(new ImageView(image));
			break;
		}
	}



	public void handleBeenden() {
		stage.close();
		System.exit(0);
	}

	public void handleAbmelden() {
		stage.close();
		main.loginWindow();
	}


	public void setStage(Stage stage) {
		this.stage = stage;
	}
}

