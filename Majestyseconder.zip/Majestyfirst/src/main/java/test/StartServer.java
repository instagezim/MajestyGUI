package test;


import clientserver.Client;
import clientserver.StarterHelp;

public class StartServer {

	public static void main(String[] args) throws Exception {
		
		StarterHelp sh = new StarterHelp();
		sh.start();

	}

}
