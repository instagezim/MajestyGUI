package ch.majesty.model;
/*
 * PLU  31.10.2018
 */

public enum CardType {MILLER, BREWER, WITCH, GUARD, KNIGHT, INNKEEPER, NOBLE

}
