INSERT INTO user(login, password, wins , losses)
VALUES
('user1','test',0 ,0),
('user2','test',0 ,0);